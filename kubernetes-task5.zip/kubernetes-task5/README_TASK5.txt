TASK 5 — Build a Kubernetes Cluster Locally with Minikube

Objective:
Deploy and manage an app (Nginx) in Kubernetes locally using Minikube.

Tools:
- Minikube
- kubectl
- Docker

---

Steps:

1. Start Minikube:
   minikube start --driver=docker

2. Deploy the app:
   kubectl apply -f deployment.yaml

3. Check pods:
   kubectl get pods

4. Expose the app:
   kubectl apply -f service.yaml

5. Check services:
   kubectl get svc

6. Open app in browser:
   minikube service nginx-service

7. Scale deployment:
   kubectl scale deployment nginx-deployment --replicas=5
   kubectl get pods

8. View pod logs:
   kubectl get pods
   kubectl logs <pod-name>

9. Optional Dashboard:
   minikube dashboard

- Screenshots is in zip file